package config

var Val ValStruct

type ValStruct struct {
	//Order_freeze_time Int64 //下单冻结时间（到时间不支付则自动取消订单）
}
